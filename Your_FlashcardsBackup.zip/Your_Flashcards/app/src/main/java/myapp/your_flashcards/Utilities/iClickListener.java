package myapp.your_flashcards.Utilities;

/**
 * Created by User on 2018/06/15.
 */

public interface iClickListener {
    void doWork();
}
