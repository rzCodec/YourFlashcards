package myapp.your_flashcards.Room_Database;

import java.util.ArrayList;

import myapp.your_flashcards.Subject.Subject;

/**
 * Created by User on 2018/06/12.
 */

public interface iReturnSubjects {
    void getSubjects(ArrayList<Subject> subjectList);
}
