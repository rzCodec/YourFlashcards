package myapp.your_flashcards;

import myapp.your_flashcards.Subject.Subject;

/**
 * Created by User on 2018/06/15.
 */

public interface iOnClickListener<T> {
    void onItemClick(T elem);
}
