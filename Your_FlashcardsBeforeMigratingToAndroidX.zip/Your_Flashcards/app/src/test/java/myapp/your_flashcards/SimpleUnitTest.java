package myapp.your_flashcards;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Created by User on 2018/12/14.
 */

public class SimpleUnitTest {
    @Test
    public void assert_TextView(){

    }
}
